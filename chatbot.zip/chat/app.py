from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

# Define trigger points and corresponding options
trigger_options = {
    'hello': ['Company Name','Technology', 'location'],
    'Company Name': ['Numetry Technology','Neubrain Solution','datamatics'],
    'Technology': ['Frontend', 'Backend', 'Fullstack'],
    'location': ['pune', 'mumbai','nashik'],  }
    

# Initialize conversation state
conversation_state = {
    'current_trigger': None
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json['message']
    response, options = generate_response(user_message)
    return jsonify({'response': response, 'options': options})

def generate_response(user_message):
    global conversation_state

    user_message = user_message.lower()

    # Check if the user message matches any trigger option
    if user_message in ['hi', 'hello']:
        conversation_state['current_trigger'] = 'hello'
        return "Hello! How can I help you?", trigger_options['hello']

    # Handle the user message based on the current conversation state
    current_trigger = conversation_state.get('current_trigger')
    if current_trigger:
        if current_trigger == 'hello':
            if user_message in ['Company Name','Technology', 'location']:
                conversation_state['current_trigger'] = user_message
                return f"You selected {user_message}. Here are your options:", trigger_options[user_message]
            else:
                return "I'm sorry, I didn't understand that. Please choose one of the options.", trigger_options['hello']
        elif current_trigger == 'Company Name':
            if user_message in ['Numetry Technology','Neubrain Solution','datamatics']:
                return "Available Soon.", []
            else:
                return "I'm sorry, I didn't understand that. Please choose one of the options.", trigger_options['Company Name']
        elif current_trigger == 'Technology':
            if user_message in ['Frontend', 'Backend', 'Fullstack']:
                return "Available Soon.", []
            else:
                return "I'm sorry, I didn't understand that. Please choose one of the options.", trigger_options['Technology']
            '''return "Resume tips are currently available soon.", []'''
        elif current_trigger == 'location':
            if user_message in ['pune', 'mumbai','nashik']:
                return "Available Soon.", []
            else:
                return "Sorry for the inconvenience.", []

    # Default response if no conditions are met
    return "I'm sorry, I didn't understand that.", []

if __name__ == '__main__':
    app.run(debug=True)


